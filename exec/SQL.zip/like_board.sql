create table like_board
(
    like_board_no int not null
        primary key,
    board_no      int null,
    user_no       int null,
    constraint FK8h0fdh01su2oo3fsb74f13w2y
        foreign key (user_no) references users (user_no),
    constraint FKj3xe3tnmm3xa6hlblmi04jiwx
        foreign key (board_no) references board (board_no)
);

INSERT INTO mydb.like_board (like_board_no, board_no, user_no) VALUES (28, 23, 24);
INSERT INTO mydb.like_board (like_board_no, board_no, user_no) VALUES (51, 50, 24);
INSERT INTO mydb.like_board (like_board_no, board_no, user_no) VALUES (65, 50, 12);
INSERT INTO mydb.like_board (like_board_no, board_no, user_no) VALUES (75, 50, 36);
INSERT INTO mydb.like_board (like_board_no, board_no, user_no) VALUES (229, 228, 32);
INSERT INTO mydb.like_board (like_board_no, board_no, user_no) VALUES (240, 224, 45);
INSERT INTO mydb.like_board (like_board_no, board_no, user_no) VALUES (241, 228, 45);
INSERT INTO mydb.like_board (like_board_no, board_no, user_no) VALUES (242, 205, 45);
INSERT INTO mydb.like_board (like_board_no, board_no, user_no) VALUES (243, 50, 45);
