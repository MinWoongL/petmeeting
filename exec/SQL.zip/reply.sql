create table reply
(
    reply_no      int           not null
        primary key,
    content       text          not null,
    created_time  bigint        not null,
    deleted_time  bigint        null,
    like_cnt      int default 0 not null,
    modified_time bigint        null,
    board_no      int           null,
    user_no       int           null,
    constraint FKb58q1nmk6q4y93f5cejg56scr
        foreign key (board_no) references board (board_no),
    constraint FKebqkbvyh1sqihitd2ppvrv797
        foreign key (user_no) references users (user_no)
);

INSERT INTO mydb.reply (reply_no, content, created_time, deleted_time, like_cnt, modified_time, board_no, user_no) VALUES (114, '정말귀엽고이쁜거같아요정말귀엽고이쁜거같아요정말귀엽고이쁜거같아요정말귀엽고이쁜거같아요정말귀엽고이쁜거같아요정말귀엽고이쁜거같아요정말귀엽고이쁜거같아요정말귀엽고이쁜거같아요정말귀엽고이쁜거같아요정말귀엽고이쁜거같아요정말귀엽고이쁜거같아요정말귀엽고이쁜거같아요정말귀엽고이쁜거같아요', 1692228362, null, 0, 1692229243, 50, 24);
INSERT INTO mydb.reply (reply_no, content, created_time, deleted_time, like_cnt, modified_time, board_no, user_no) VALUES (128, 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa', 1692234574, null, 0, 1692234602, 50, 43);
INSERT INTO mydb.reply (reply_no, content, created_time, deleted_time, like_cnt, modified_time, board_no, user_no) VALUES (130, '정말귀엽고이쁜거같아요정말귀엽고이쁜거같아요정말귀엽고이쁜거같아요정말귀엽고이쁜거같아요정말귀엽고이', 1692234627, null, 0, null, 50, 43);
INSERT INTO mydb.reply (reply_no, content, created_time, deleted_time, like_cnt, modified_time, board_no, user_no) VALUES (132, 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa
', 1692234825, null, 0, 1692234895, 50, 43);
INSERT INTO mydb.reply (reply_no, content, created_time, deleted_time, like_cnt, modified_time, board_no, user_no) VALUES (134, 'zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz', 1692234870, null, 0, null, 50, 43);
INSERT INTO mydb.reply (reply_no, content, created_time, deleted_time, like_cnt, modified_time, board_no, user_no) VALUES (225, '달마시안, 귀엽고 사랑스러운 매력으로 마음을 사로잡는 존재입니다. ?❤️', 1692276437, null, 0, null, 223, 32);
INSERT INTO mydb.reply (reply_no, content, created_time, deleted_time, like_cnt, modified_time, board_no, user_no) VALUES (226, '강아지, 너무 귀여워서 눈이 놀라움으로 빛나요! ?❤️', 1692276457, null, 0, null, 185, 32);
INSERT INTO mydb.reply (reply_no, content, created_time, deleted_time, like_cnt, modified_time, board_no, user_no) VALUES (227, '강아지들의 귀엽고 사랑스러운 모습은 마음을 따뜻하게 만들어요. 그 눈빛 하나로 많은 행복을 전해주는 존재입니다. ?❤️', 1692276478, null, 0, null, 205, 32);
INSERT INTO mydb.reply (reply_no, content, created_time, deleted_time, like_cnt, modified_time, board_no, user_no) VALUES (239, '푸들과 함께하는 시간은 마치 작은 행복들로 가득차며, 그들의 사랑과 충성은 우리에게 큰 위안과 힘을 줍니다. 그들과 함께하는 산책이나 놀이는 언제나 행복하고 즐거운 순간으로 남을 것이며, 그들의 꼬리 흔들림과 쾌활한 모습은 우리에게 끊임없는 기쁨을 선사합니다.', 1692277141, null, 0, null, 224, 45);
