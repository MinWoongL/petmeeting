create table shelter
(
    dog_no             int          null,
    location           varchar(150) null,
    on_broadcast_title varchar(60)  null,
    regist_image_path  varchar(255) not null,
    site_url           varchar(50)  null,
    user_no            int          not null
        primary key,
    constraint FKen8l0a6jd4pm3df4jc5wbkx5f
        foreign key (user_no) references users (user_no)
);

INSERT INTO mydb.shelter (dog_no, location, on_broadcast_title, regist_image_path, site_url, user_no) VALUES (54, '서울특별시 강남구 역삼동 테헤란로 212', '초롱이 이 방송 중입니다.', '521d536e-17cb-44d3-a62d-717ec955af8a_multicampus.jpg', 'https://i9a203.p.ssafy.io/', 12);
INSERT INTO mydb.shelter (dog_no, location, on_broadcast_title, regist_image_path, site_url, user_no) VALUES (null, '13579', null, '75862d7e-efac-4252-bc60-af6320eab879_강아지1.jpg', '111', 30);
INSERT INTO mydb.shelter (dog_no, location, on_broadcast_title, regist_image_path, site_url, user_no) VALUES (null, '경기도 안양시 인근', null, '609dc095-74d2-4392-9d63-7f285181bf56_안양시건물.JPG', 'http://anyangshelter', 37);
INSERT INTO mydb.shelter (dog_no, location, on_broadcast_title, regist_image_path, site_url, user_no) VALUES (null, '충북 청주시 보호소', null, '012f545b-771d-4fed-a630-188ddb3d056a_청주시보호소.JPG', 'http://chjushelter', 38);
INSERT INTO mydb.shelter (dog_no, location, on_broadcast_title, regist_image_path, site_url, user_no) VALUES (null, '서울시성동구유기동물보호소', null, '07cdfc4c-3a60-4bbb-88ec-f234e80deb6f_서울시보호소.JPG', 'http://sdshelter.com', 39);
INSERT INTO mydb.shelter (dog_no, location, on_broadcast_title, regist_image_path, site_url, user_no) VALUES (null, '인천시유기동물보호소', null, '7900fdb9-b1eb-44c2-bffe-fc8adf9663a1_인천시보호소.JPG', 'http://icshelter.com', 46);
INSERT INTO mydb.shelter (dog_no, location, on_broadcast_title, regist_image_path, site_url, user_no) VALUES (null, '역삼', null, 'aac39f9c-0823-433a-ac6b-e0c0d41efa87_image.png', 'https://qhghth.com', 49);
