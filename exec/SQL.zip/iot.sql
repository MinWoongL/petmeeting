create table iot
(
    iot_no     int          not null
        primary key,
    command    varchar(255) null,
    iot_group  varchar(255) null,
    shelter_no int          null,
    constraint FK9mc2bc4vpodkg2bjvsnva5ttx
        foreign key (shelter_no) references shelter (user_no)
);

