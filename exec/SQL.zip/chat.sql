create table chat
(
    chat_no      int    not null
        primary key,
    content      text   not null,
    created_time bigint not null,
    shelter_no   int    null,
    user_no      int    null,
    constraint FK3hyuuu4pa9blprs3n2gxedlg9
        foreign key (shelter_no) references shelter (user_no),
    constraint FKlrct1cp8r1l2b8g2n7sa18ind
        foreign key (user_no) references users (user_no)
);

INSERT INTO mydb.chat (chat_no, content, created_time, shelter_no, user_no) VALUES (81, '오 유기견들도 채팅을 칠수 있나보네요. 신기합니다!', 1692174563, 12, 36);
INSERT INTO mydb.chat (chat_no, content, created_time, shelter_no, user_no) VALUES (138, '안ㄴ녕하세요', 1692235305, 30, 32);
INSERT INTO mydb.chat (chat_no, content, created_time, shelter_no, user_no) VALUES (244, '네 채팅 남겨주셔서 감사합니다', 1692277886, 12, 12);
INSERT INTO mydb.chat (chat_no, content, created_time, shelter_no, user_no) VALUES (245, '대충강아지 너무 귀여워요', 1692278410, 30, 44);
INSERT INTO mydb.chat (chat_no, content, created_time, shelter_no, user_no) VALUES (246, '안녕하세요 같은 보호소끼리 친하게 지내요', 1692278491, 38, 12);
