create table member
(
    adopted       bit default b'0' not null,
    holding_token int default 0    not null,
    user_no       int              not null
        primary key,
    constraint FKeeq9w0a7c20ylil0yhyuw8k1y
        foreign key (user_no) references users (user_no)
);

INSERT INTO mydb.member (adopted, holding_token, user_no) VALUES (false, 12, 13);
INSERT INTO mydb.member (adopted, holding_token, user_no) VALUES (false, 12, 20);
INSERT INTO mydb.member (adopted, holding_token, user_no) VALUES (true, 1, 21);
INSERT INTO mydb.member (adopted, holding_token, user_no) VALUES (false, 0, 22);
INSERT INTO mydb.member (adopted, holding_token, user_no) VALUES (false, 0, 23);
INSERT INTO mydb.member (adopted, holding_token, user_no) VALUES (true, 45, 24);
INSERT INTO mydb.member (adopted, holding_token, user_no) VALUES (false, 0, 29);
INSERT INTO mydb.member (adopted, holding_token, user_no) VALUES (false, 0, 31);
INSERT INTO mydb.member (adopted, holding_token, user_no) VALUES (true, 0, 32);
INSERT INTO mydb.member (adopted, holding_token, user_no) VALUES (false, 20, 33);
INSERT INTO mydb.member (adopted, holding_token, user_no) VALUES (false, 0, 36);
INSERT INTO mydb.member (adopted, holding_token, user_no) VALUES (false, 10, 41);
INSERT INTO mydb.member (adopted, holding_token, user_no) VALUES (true, 2, 42);
INSERT INTO mydb.member (adopted, holding_token, user_no) VALUES (false, 2, 43);
INSERT INTO mydb.member (adopted, holding_token, user_no) VALUES (true, 10, 44);
INSERT INTO mydb.member (adopted, holding_token, user_no) VALUES (false, 0, 45);
INSERT INTO mydb.member (adopted, holding_token, user_no) VALUES (false, 0, 47);
