create table bookmark_dog
(
    bookmark_dog_no int not null
        primary key,
    dog_no          int null,
    member_no       int null,
    constraint FKmk7h36cwh0nv7uuu01dhac3yf
        foreign key (member_no) references member (user_no),
    constraint FKrl2gr0l5utoo39dwmrya9nq9k
        foreign key (dog_no) references dog (dog_no)
);

INSERT INTO mydb.bookmark_dog (bookmark_dog_no, dog_no, member_no) VALUES (4, 1, 21);
INSERT INTO mydb.bookmark_dog (bookmark_dog_no, dog_no, member_no) VALUES (83, 1, 36);
INSERT INTO mydb.bookmark_dog (bookmark_dog_no, dog_no, member_no) VALUES (84, 56, 36);
INSERT INTO mydb.bookmark_dog (bookmark_dog_no, dog_no, member_no) VALUES (124, 99, 43);
INSERT INTO mydb.bookmark_dog (bookmark_dog_no, dog_no, member_no) VALUES (126, 92, 43);
INSERT INTO mydb.bookmark_dog (bookmark_dog_no, dog_no, member_no) VALUES (141, 54, 42);
INSERT INTO mydb.bookmark_dog (bookmark_dog_no, dog_no, member_no) VALUES (208, 188, 44);
INSERT INTO mydb.bookmark_dog (bookmark_dog_no, dog_no, member_no) VALUES (233, 56, 32);
INSERT INTO mydb.bookmark_dog (bookmark_dog_no, dog_no, member_no) VALUES (234, 103, 32);
