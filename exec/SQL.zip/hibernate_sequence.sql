create table hibernate_sequence
(
    next_val bigint null
);

INSERT INTO mydb.hibernate_sequence (next_val) VALUES (247);
