create table like_reply
(
    like_reply_no int not null
        primary key,
    reply_no      int null,
    user_no       int null,
    constraint FKlcpusigbb8ikty2m0yba3k985
        foreign key (user_no) references users (user_no),
    constraint FKm4msc2aca4f55ux1rh7axkxn2
        foreign key (reply_no) references reply (reply_no)
);

