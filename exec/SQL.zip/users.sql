create table users
(
    user_group   varchar(31)      not null,
    user_no      int auto_increment
        primary key,
    image_path   varchar(255)     null,
    is_activated bit default b'1' not null,
    is_deleted   bit default b'0' not null,
    join_date    bigint           not null,
    name         varchar(50)      not null,
    password     varchar(255)     not null,
    phone_number varchar(50)      null,
    user_id      varchar(50)      not null,
    constraint UK_6efs5vmce86ymf5q7lmvn2uuf
        unique (user_id)
);

INSERT INTO mydb.users (user_group, user_no, image_path, is_activated, is_deleted, join_date, name, password, phone_number, user_id) VALUES ('Shelter', 12, '521d536e-17cb-44d3-a62d-717ec955af8a_multicampus.jpg', true, false, 1691984814, '싸피동물보호소', '$2a$10$vK6NiVXGjf8sdPuH9Rjefu0CRtr4WfgFp3jSyDzV5vWZ0HvGplNzy', '010-0000-0000', '싸피동물보호소');
INSERT INTO mydb.users (user_group, user_no, image_path, is_activated, is_deleted, join_date, name, password, phone_number, user_id) VALUES ('Member', 13, 'profile1.png', true, false, 1691985370, '민웅민웅', '$2a$10$DguNeoZL8Syf/IleIuXLmOQbKkb5ebipFvhGYBhRFAAIEKDl9p1sG', '010-0000-0000', '민웅민웅');
INSERT INTO mydb.users (user_group, user_no, image_path, is_activated, is_deleted, join_date, name, password, phone_number, user_id) VALUES ('Member', 20, '', true, false, 1691987671, '1233333', '$2a$10$l3xB8YH8I7Zo4t7Kn5Wp..ZlFBFT3tUGgHDlAxyuge9CBAMRfe9ia', '123', '사용자11');
INSERT INTO mydb.users (user_group, user_no, image_path, is_activated, is_deleted, join_date, name, password, phone_number, user_id) VALUES ('Member', 21, 'profile6.png', true, false, 1691988700, 'cho', '$2a$10$y8wQMxo0LXfij2cbxT4S5.4xk38h6h6k7Et8cYZ1VjIcsUvi0T5Y6', '11234432', 'asdfasdf');
INSERT INTO mydb.users (user_group, user_no, image_path, is_activated, is_deleted, join_date, name, password, phone_number, user_id) VALUES ('Member', 22, '', true, false, 1691990128, '123', '$2a$10$G9mbMDYUp/vqLaKUPH7naeowl5/O0WAikgsYS3lRnyyeJJ1eOvEqW', '123', '사용자112');
INSERT INTO mydb.users (user_group, user_no, image_path, is_activated, is_deleted, join_date, name, password, phone_number, user_id) VALUES ('Member', 23, '', true, false, 1691990583, 'ssafy', '$2a$10$BmkWkOpraqgyqJM/xhvH8uzapdHdxRQ.//Ew3N71ELUYpwrnZlQQ.', '123123', 'ssafy');
INSERT INTO mydb.users (user_group, user_no, image_path, is_activated, is_deleted, join_date, name, password, phone_number, user_id) VALUES ('Member', 24, 'profile3.png', true, false, 1691991841, '강아지애호가', '$2a$10$VCTV0hqin9Wv6AqZkuNqseyVD/QgBfhLgse3ZxQjN2LeMkJbO7L2O', '010-5523-1242', 'qwer');
INSERT INTO mydb.users (user_group, user_no, image_path, is_activated, is_deleted, join_date, name, password, phone_number, user_id) VALUES ('Member', 29, '', true, false, 1691993681, '123', '$2a$10$euOZDZOYIKXTowbRmRmcn.mOltxSHkD3uwXfCtU8ehGV.jEVnb0na', '123', '사용자12');
INSERT INTO mydb.users (user_group, user_no, image_path, is_activated, is_deleted, join_date, name, password, phone_number, user_id) VALUES ('Shelter', 30, '75862d7e-efac-4252-bc60-af6320eab879_강아지1.jpg', true, false, 1691995184, '이름이름이름', '$2a$10$DdfS67KMxsjgSvhv1flYbudFaTIBdiW3yjYcYh3qLOFIXRd35EbMe', '111', '보호소17');
INSERT INTO mydb.users (user_group, user_no, image_path, is_activated, is_deleted, join_date, name, password, phone_number, user_id) VALUES ('Member', 31, 'profile6.png', true, false, 1692102759, '강형욱', '$2a$10$cmlg4uXLaRotkZTVxZPx1ulXKg.8ACWgPPxR5R29dIMfx55gSraDC', '010-5582-6311', 'member1004');
INSERT INTO mydb.users (user_group, user_no, image_path, is_activated, is_deleted, join_date, name, password, phone_number, user_id) VALUES ('Member', 32, 'cyy.png', true, false, 1692161051, '조윤영', '$2a$10$JF9wax81gT2FKZ4AckVD1.1EVFirl5OpBP63Ya//l4OGs816PEjne', '010-1234-4567', '조윤영');
INSERT INTO mydb.users (user_group, user_no, image_path, is_activated, is_deleted, join_date, name, password, phone_number, user_id) VALUES ('Member', 33, 'profile2.png', true, false, 1692168649, '123', '$2a$10$YD/FX1GUs9m/Egn5L7ED2uyfc6/oSCpcfLKXYYWnmhCacUU0gLCyC', '123', 'TEST11');
INSERT INTO mydb.users (user_group, user_no, image_path, is_activated, is_deleted, join_date, name, password, phone_number, user_id) VALUES ('Member', 36, 'profile4.png', true, false, 1692174044, '김코치', '$2a$10$4DO0S0rmgwFq7yiiuazvUugaGOrsV1oEJWIPCJ0f9TZEr/Nwvz1NG', '01000000000', 'whdtmql1228');
INSERT INTO mydb.users (user_group, user_no, image_path, is_activated, is_deleted, join_date, name, password, phone_number, user_id) VALUES ('Shelter', 37, '609dc095-74d2-4392-9d63-7f285181bf56_안양시건물.JPG', true, false, 1692192859, '안양시유기동물보호소', '$2a$10$8t7nsCyurnrtf.9qD6ENH./9G83Tr55SLTQAldeBIxTttPLNfHz2C', '010-0101-0101', '안양시유기동물 보호소');
INSERT INTO mydb.users (user_group, user_no, image_path, is_activated, is_deleted, join_date, name, password, phone_number, user_id) VALUES ('Shelter', 38, '012f545b-771d-4fed-a630-188ddb3d056a_청주시보호소.JPG', true, false, 1692194582, '충북 청주시 보호소', '$2a$10$AJqzlq1crlEN3NxgkvW3y..XMvKO8gPxTlsjJB567H7EzOd1VMHkC', '010-0101-0102', '충북 청주시 보호소');
INSERT INTO mydb.users (user_group, user_no, image_path, is_activated, is_deleted, join_date, name, password, phone_number, user_id) VALUES ('Shelter', 39, '07cdfc4c-3a60-4bbb-88ec-f234e80deb6f_서울시보호소.JPG', true, false, 1692196653, '서울시성동구유기동물보호소', '$2a$10$RsyWur.fBjvJFoGK8mLbYOT7RP/nHTbDQmEvhA4KE0yXZUGy4aWqa', '010-0000-0009', '서울시성동구유기동물보호소');
INSERT INTO mydb.users (user_group, user_no, image_path, is_activated, is_deleted, join_date, name, password, phone_number, user_id) VALUES ('Member', 41, '', true, false, 1692198569, '사용자17', '$2a$10$sj2j7mg2ELZdtmf/i2CrKehdo5f1IjzqjB.ApP4DofEeQqS/WVeQO', '123', '사용자17');
INSERT INTO mydb.users (user_group, user_no, image_path, is_activated, is_deleted, join_date, name, password, phone_number, user_id) VALUES ('Member', 42, 'profile3.png', true, false, 1692234162, 'ccc', '$2a$10$hUkB33KCmcKf1CyBe5lfKuII4mWbDMK71lvABmuhG8krVSeldPRD.', '0105555555', 'sweetchild314');
INSERT INTO mydb.users (user_group, user_no, image_path, is_activated, is_deleted, join_date, name, password, phone_number, user_id) VALUES ('Member', 43, '', true, false, 1692234177, 'asdasd', '$2a$10$7dyCfphi8ubp.ua0jjLFWeo0RQ0DQz1Q0yq/0zIgZTaH6wooFIAhm', 'asdasd', 'asdasd');
INSERT INTO mydb.users (user_group, user_no, image_path, is_activated, is_deleted, join_date, name, password, phone_number, user_id) VALUES ('Member', 44, '', true, false, 1692236875, '사용자', '$2a$10$EZsMp7Q9nIEINHAJfwYVcuMi7CBAvaIOGCX4LsGSPy9OEZZ9H6r9m', '010-0101-0101', '사용자1');
INSERT INTO mydb.users (user_group, user_no, image_path, is_activated, is_deleted, join_date, name, password, phone_number, user_id) VALUES ('Member', 45, '', true, false, 1692236896, '보호하고싶소', '$2a$10$rOofZP9LA6zHHMP0hwD/Zeuhecmym0Coyn1eSXfrqI3giLoiY9fam', '010-0000-0000', '보호소1');
INSERT INTO mydb.users (user_group, user_no, image_path, is_activated, is_deleted, join_date, name, password, phone_number, user_id) VALUES ('Shelter', 46, '7900fdb9-b1eb-44c2-bffe-fc8adf9663a1_인천시보호소.JPG', true, false, 1692253332, '인천시유기동물보호소', '$2a$10$5MX8hkN.laMlORjO0zAut.Qz/UmpY12gV/flwIvIY/tIcp5gPunjG', '010-0000-0008', '인천시유기동물보호소');
INSERT INTO mydb.users (user_group, user_no, image_path, is_activated, is_deleted, join_date, name, password, phone_number, user_id) VALUES ('Member', 47, '', true, false, 1692256739, 'user1111', '$2a$10$s/.b0EzKt5/PwS9Z8x1h9.WDzrp7PNzfR2FHEfjp0i5R8UzMPkm.O', '01099999999', 'user1111');
INSERT INTO mydb.users (user_group, user_no, image_path, is_activated, is_deleted, join_date, name, password, phone_number, user_id) VALUES ('Shelter', 48, 'profile6.png', true, false, 1692257873, '즐거운보호소', '$2a$10$xyFHG6uKytJeK5c2ttQyrOTH0qHCM/TYSPdwMdTpT8UM7zdFHHU3m', '010-3214-2132', '보호소12');
INSERT INTO mydb.users (user_group, user_no, image_path, is_activated, is_deleted, join_date, name, password, phone_number, user_id) VALUES ('Shelter', 49, 'aac39f9c-0823-433a-ac6b-e0c0d41efa87_image.png', true, false, 1692259249, '보호소56', '$2a$10$JDEqe3xUw3X9FddkUP/ZJuQhKZ0YdbCNqBl1nj6dzhSxj8GrmE1dm', '01022332233', 'qhghth56');
