create table charge
(
    charge_no    int          not null
        primary key,
    charge_time  bigint       not null,
    charge_value int          not null,
    tid          varchar(100) not null,
    member_no    int          not null,
    constraint FK8chlhu1g72xwmicldw0tdpfvj
        foreign key (member_no) references member (user_no)
);

INSERT INTO mydb.charge (charge_no, charge_time, charge_value, tid, member_no) VALUES (2, 1691988898, 10000, 'T4d9b3854ce74cf5a6fc', 21);
INSERT INTO mydb.charge (charge_no, charge_time, charge_value, tid, member_no) VALUES (21, 1692016982, 5000, 'T4da213376b90283c437', 13);
INSERT INTO mydb.charge (charge_no, charge_time, charge_value, tid, member_no) VALUES (29, 1692102019, 1000000, 'T4db6d6776b90283cc77', 20);
INSERT INTO mydb.charge (charge_no, charge_time, charge_value, tid, member_no) VALUES (47, 1692144781, 5000, 'T4dc14754ce74cf5c26c', 24);
INSERT INTO mydb.charge (charge_no, charge_time, charge_value, tid, member_no) VALUES (52, 1692159520, 10000, 'T4dc4e0f76b90283d910', 13);
INSERT INTO mydb.charge (charge_no, charge_time, charge_value, tid, member_no) VALUES (53, 1692160191, 1000000, 'T4dc50ab4ce74cf5c8ec', 13);
INSERT INTO mydb.charge (charge_no, charge_time, charge_value, tid, member_no) VALUES (55, 1692162608, 50000, 'T4dc5a144ce74cf5c96b', 13);
INSERT INTO mydb.charge (charge_no, charge_time, charge_value, tid, member_no) VALUES (58, 1692164999, 1000000, 'T4dc636e4ce74cf5ca34', 32);
INSERT INTO mydb.charge (charge_no, charge_time, charge_value, tid, member_no) VALUES (71, 1692168682, 1000000, 'T4dc71d676b90283dde1', 33);
INSERT INTO mydb.charge (charge_no, charge_time, charge_value, tid, member_no) VALUES (72, 1692170179, 1000000, 'T4dc77b076b90283de45', 33);
INSERT INTO mydb.charge (charge_no, charge_time, charge_value, tid, member_no) VALUES (73, 1692172671, 1000000, 'T4dc816d76b90283df18', 20);
INSERT INTO mydb.charge (charge_no, charge_time, charge_value, tid, member_no) VALUES (86, 1692184396, 1000000, 'T4dcaf3576b90283e409', 13);
INSERT INTO mydb.charge (charge_no, charge_time, charge_value, tid, member_no) VALUES (107, 1692198602, 1000000, 'T4dce6b34ce74cf5d52f', 41);
INSERT INTO mydb.charge (charge_no, charge_time, charge_value, tid, member_no) VALUES (120, 1692234282, 5000, 'T4dd720776b90283e948', 43);
INSERT INTO mydb.charge (charge_no, charge_time, charge_value, tid, member_no) VALUES (121, 1692234287, 5000, 'T4dd720076b90283e947', 42);
INSERT INTO mydb.charge (charge_no, charge_time, charge_value, tid, member_no) VALUES (184, 1692249972, 1000000, 'T4ddaf604ce74cf5dcc4', 13);
INSERT INTO mydb.charge (charge_no, charge_time, charge_value, tid, member_no) VALUES (195, 1692256860, 5000, 'T4ddca4c4ce74cf5df36', 32);
INSERT INTO mydb.charge (charge_no, charge_time, charge_value, tid, member_no) VALUES (197, 1692258680, 50000, 'T4ddd15d4ce74cf5dfd9', 32);
INSERT INTO mydb.charge (charge_no, charge_time, charge_value, tid, member_no) VALUES (199, 1692260169, 50000, 'T4ddd73076b90283f0d2', 13);
INSERT INTO mydb.charge (charge_no, charge_time, charge_value, tid, member_no) VALUES (200, 1692260408, 100000, 'T4ddd82376b90283f0dd', 24);
INSERT INTO mydb.charge (charge_no, charge_time, charge_value, tid, member_no) VALUES (202, 1692260710, 50000, 'T4ddd95676b90283f0f6', 44);
INSERT INTO mydb.charge (charge_no, charge_time, charge_value, tid, member_no) VALUES (203, 1692260800, 1000000, 'T4ddd9ab4ce74cf5e07d', 24);
INSERT INTO mydb.charge (charge_no, charge_time, charge_value, tid, member_no) VALUES (204, 1692260844, 50000, 'T4ddd9dd4ce74cf5e081', 24);
INSERT INTO mydb.charge (charge_no, charge_time, charge_value, tid, member_no) VALUES (206, 1692260876, 50000, 'T4ddd9f776b90283f10a', 24);
INSERT INTO mydb.charge (charge_no, charge_time, charge_value, tid, member_no) VALUES (212, 1692260929, 5000, 'T4ddda2f76b90283f10d', 13);
INSERT INTO mydb.charge (charge_no, charge_time, charge_value, tid, member_no) VALUES (214, 1692260970, 500000, 'T4ddda584ce74cf5e08c', 13);
INSERT INTO mydb.charge (charge_no, charge_time, charge_value, tid, member_no) VALUES (215, 1692261146, 50000, 'T4dddb084ce74cf5e0a1', 24);
INSERT INTO mydb.charge (charge_no, charge_time, charge_value, tid, member_no) VALUES (216, 1692261492, 5000, 'T4dddc5e76b90283f13a', 13);
INSERT INTO mydb.charge (charge_no, charge_time, charge_value, tid, member_no) VALUES (217, 1692261691, 50000, 'T4dddd2876b90283f143', 32);
