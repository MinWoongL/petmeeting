create table inquiry
(
    inquiry_no    int              not null
        primary key,
    content       text             not null,
    created_time  bigint           not null,
    deleted_time  bigint           null,
    modified_time bigint           null,
    status        bit default b'0' null,
    title         varchar(100)     not null,
    answer_no     int              null,
    user_no       int              null,
    constraint FK1c1gn70ai4p3tt5ayxfj3wsiq
        foreign key (user_no) references users (user_no),
    constraint FK5jo2p0j95ogj219kg4echal8y
        foreign key (answer_no) references answer (answer_no)
);

INSERT INTO mydb.inquiry (inquiry_no, content, created_time, deleted_time, modified_time, status, title, answer_no, user_no) VALUES (15, '', 1691989602, 1691989660, 1691989649, false, '', null, 21);
INSERT INTO mydb.inquiry (inquiry_no, content, created_time, deleted_time, modified_time, status, title, answer_no, user_no) VALUES (22, 'ddd', 1692099723, 1692099868, null, false, 'ddd', null, 24);
INSERT INTO mydb.inquiry (inquiry_no, content, created_time, deleted_time, modified_time, status, title, answer_no, user_no) VALUES (24, 'dd', 1692099893, 1692101212, 1692100266, false, 'ㅇㄻㅇㄴ', null, 24);
INSERT INTO mydb.inquiry (inquiry_no, content, created_time, deleted_time, modified_time, status, title, answer_no, user_no) VALUES (68, 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa
aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa', 1692165509, null, 1692165538, false, 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa', null, 12);
INSERT INTO mydb.inquiry (inquiry_no, content, created_time, deleted_time, modified_time, status, title, answer_no, user_no) VALUES (76, '제곧내', 1692174427, null, null, false, '포인트랑 멍코인은 어떻게 다른가요?', null, 36);
INSERT INTO mydb.inquiry (inquiry_no, content, created_time, deleted_time, modified_time, status, title, answer_no, user_no) VALUES (115, 'ddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd', 1692229427, null, null, false, 'dddddddddddddddddddddddddddddddddddddddddddddddddd', null, 24);
INSERT INTO mydb.inquiry (inquiry_no, content, created_time, deleted_time, modified_time, status, title, answer_no, user_no) VALUES (116, 'ddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd', 1692229428, null, null, false, 'dddddddddddddddddddddddddddddddddddddddddddddddddd', null, 24);
INSERT INTO mydb.inquiry (inquiry_no, content, created_time, deleted_time, modified_time, status, title, answer_no, user_no) VALUES (136, 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasasasasasaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa', 1692234921, null, 1692234930, false, 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa', null, 43);
INSERT INTO mydb.inquiry (inquiry_no, content, created_time, deleted_time, modified_time, status, title, answer_no, user_no) VALUES (140, '분양하고 싶어요', 1692235395, null, null, false, '안녕하세요.', null, 42);
INSERT INTO mydb.inquiry (inquiry_no, content, created_time, deleted_time, modified_time, status, title, answer_no, user_no) VALUES (222, '안녕하신가요?', 1692276116, null, null, false, '관리자님께 문의드립니다.', null, 44);
