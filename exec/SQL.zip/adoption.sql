create table adoption
(
    adoption_no     int                           not null
        primary key,
    additional      text                          null,
    adoption_status varchar(20) default 'WAITING' not null,
    age             int                           not null,
    call_time       varchar(255)                  not null,
    gender          char(6)                       not null,
    job             varchar(50)                   not null,
    name            varchar(50)                   not null,
    pet_experience  bit                           not null,
    phone_number    varchar(20)                   not null,
    residence       varchar(20)                   not null,
    dog_no          int                           null,
    member_no       int                           null,
    shelter_no      int                           null,
    constraint FK8wr4i736y92md71suxi5ugsm8
        foreign key (shelter_no) references shelter (user_no),
    constraint FKn36f69q8sd6blfsfg2ix4exy0
        foreign key (dog_no) references dog (dog_no),
    constraint FKqu5muqiqt9xno3h8a3muq879r
        foreign key (member_no) references member (user_no)
);

INSERT INTO mydb.adoption (adoption_no, additional, adoption_status, age, call_time, gender, job, name, pet_experience, phone_number, residence, dog_no, member_no, shelter_no) VALUES (74, '나만 댕댕이없어,,', 'WAITING', 29, 'anytime', 'MALE', '코치', '김코치', true, '01000000000', '서울', 56, 36, 12);
INSERT INTO mydb.adoption (adoption_no, additional, adoption_status, age, call_time, gender, job, name, pet_experience, phone_number, residence, dog_no, member_no, shelter_no) VALUES (122, '이쁜이 보내주세요', 'ADOPT_SUCCESS', 18, '오후3시', 'MALE', '무직', '최씨', false, '0106666666', '분당', 57, 42, 12);
INSERT INTO mydb.adoption (adoption_no, additional, adoption_status, age, call_time, gender, job, name, pet_experience, phone_number, residence, dog_no, member_no, shelter_no) VALUES (127, '', 'WAITING', 23, 'asd', 'FEMALE', 'asd', 'asdasd', false, 'asdasd', 'asd', 96, 43, 38);
INSERT INTO mydb.adoption (adoption_no, additional, adoption_status, age, call_time, gender, job, name, pet_experience, phone_number, residence, dog_no, member_no, shelter_no) VALUES (201, '정말 데려오고 싶어요', 'WAITING', 22, '오후 8시', 'MALE', '자영업', '김사용', true, '010-3213-3232', '경기', 99, 44, 38);
INSERT INTO mydb.adoption (adoption_no, additional, adoption_status, age, call_time, gender, job, name, pet_experience, phone_number, residence, dog_no, member_no, shelter_no) VALUES (236, '저 꼭 키우고 싶어요', 'WAITING', 28, '새벽 3시', 'FEMALE', '부유한 백수', '조윤영', true, '010-1288-1255', '경기', 1, 32, 12);
INSERT INTO mydb.adoption (adoption_no, additional, adoption_status, age, call_time, gender, job, name, pet_experience, phone_number, residence, dog_no, member_no, shelter_no) VALUES (237, '쿠키 좋아합니다', 'WAITING', 28, '오후 8시', 'FEMALE', '자영업', '조윤영', false, '010-5523-1242', '경기', 96, 32, 38);
INSERT INTO mydb.adoption (adoption_no, additional, adoption_status, age, call_time, gender, job, name, pet_experience, phone_number, residence, dog_no, member_no, shelter_no) VALUES (238, '잘 키울게요!', 'WAITING', 35, '오후 3시', 'MALE', '회사원', '강형욱', true, '031-2344-1023', '서울', 1, 44, 12);
