create table donation
(
    donation_no  int    not null
        primary key,
    donate_time  bigint null,
    donate_value int    null,
    dog_no       int    null,
    member_no    int    null,
    shelter_no   int    null,
    constraint FKa5ke8d3g44usljk3fk9q6xko1
        foreign key (member_no) references member (user_no),
    constraint FKe48khwdoeoxbjeg5x0mqe2v7p
        foreign key (dog_no) references dog (dog_no),
    constraint FKkght5s8qpkjyjffl06w7m7m8j
        foreign key (shelter_no) references shelter (user_no)
);

INSERT INTO mydb.donation (donation_no, donate_time, donate_value, dog_no, member_no, shelter_no) VALUES (109, 1692198753, 10000, 91, 41, 37);
INSERT INTO mydb.donation (donation_no, donate_time, donate_value, dog_no, member_no, shelter_no) VALUES (117, 1692232472, 20000, 54, 13, 12);
INSERT INTO mydb.donation (donation_no, donate_time, donate_value, dog_no, member_no, shelter_no) VALUES (118, 1692232807, 50000, 54, 13, 12);
INSERT INTO mydb.donation (donation_no, donate_time, donate_value, dog_no, member_no, shelter_no) VALUES (119, 1692233411, 50000, 54, 13, 12);
INSERT INTO mydb.donation (donation_no, donate_time, donate_value, dog_no, member_no, shelter_no) VALUES (137, 1692235248, 100000, 1, 32, 12);
INSERT INTO mydb.donation (donation_no, donate_time, donate_value, dog_no, member_no, shelter_no) VALUES (139, 1692235356, 166, 135, 42, 12);
INSERT INTO mydb.donation (donation_no, donate_time, donate_value, dog_no, member_no, shelter_no) VALUES (143, 1692235567, 300, 135, 42, 12);
INSERT INTO mydb.donation (donation_no, donate_time, donate_value, dog_no, member_no, shelter_no) VALUES (144, 1692235580, 300, 135, 42, 12);
INSERT INTO mydb.donation (donation_no, donate_time, donate_value, dog_no, member_no, shelter_no) VALUES (145, 1692235583, 300, 135, 42, 12);
INSERT INTO mydb.donation (donation_no, donate_time, donate_value, dog_no, member_no, shelter_no) VALUES (146, 1692235584, 300, 135, 42, 12);
INSERT INTO mydb.donation (donation_no, donate_time, donate_value, dog_no, member_no, shelter_no) VALUES (147, 1692235589, 300, 135, 42, 12);
INSERT INTO mydb.donation (donation_no, donate_time, donate_value, dog_no, member_no, shelter_no) VALUES (148, 1692235592, 300, 135, 42, 12);
INSERT INTO mydb.donation (donation_no, donate_time, donate_value, dog_no, member_no, shelter_no) VALUES (149, 1692235603, 13, 135, 42, 12);
INSERT INTO mydb.donation (donation_no, donate_time, donate_value, dog_no, member_no, shelter_no) VALUES (150, 1692235605, 13, 135, 42, 12);
INSERT INTO mydb.donation (donation_no, donate_time, donate_value, dog_no, member_no, shelter_no) VALUES (151, 1692235606, 13, 135, 42, 12);
INSERT INTO mydb.donation (donation_no, donate_time, donate_value, dog_no, member_no, shelter_no) VALUES (152, 1692237046, 10000, 56, 20, 12);
INSERT INTO mydb.donation (donation_no, donate_time, donate_value, dog_no, member_no, shelter_no) VALUES (153, 1692237853, 22, 1, 32, 12);
INSERT INTO mydb.donation (donation_no, donate_time, donate_value, dog_no, member_no, shelter_no) VALUES (154, 1692237937, 22, 1, 32, 12);
INSERT INTO mydb.donation (donation_no, donate_time, donate_value, dog_no, member_no, shelter_no) VALUES (155, 1692237946, 22, 1, 32, 12);
INSERT INTO mydb.donation (donation_no, donate_time, donate_value, dog_no, member_no, shelter_no) VALUES (156, 1692237991, 22, 1, 32, 12);
INSERT INTO mydb.donation (donation_no, donate_time, donate_value, dog_no, member_no, shelter_no) VALUES (157, 1692238079, 222, 54, 24, 12);
INSERT INTO mydb.donation (donation_no, donate_time, donate_value, dog_no, member_no, shelter_no) VALUES (158, 1692238106, 22, 54, 24, 12);
INSERT INTO mydb.donation (donation_no, donate_time, donate_value, dog_no, member_no, shelter_no) VALUES (159, 1692238123, 22, 54, 24, 12);
INSERT INTO mydb.donation (donation_no, donate_time, donate_value, dog_no, member_no, shelter_no) VALUES (160, 1692238135, 22, 54, 24, 12);
INSERT INTO mydb.donation (donation_no, donate_time, donate_value, dog_no, member_no, shelter_no) VALUES (161, 1692238148, 22, 54, 24, 12);
INSERT INTO mydb.donation (donation_no, donate_time, donate_value, dog_no, member_no, shelter_no) VALUES (162, 1692238380, 555, 54, 24, 12);
INSERT INTO mydb.donation (donation_no, donate_time, donate_value, dog_no, member_no, shelter_no) VALUES (163, 1692238432, 33, 54, 24, 12);
INSERT INTO mydb.donation (donation_no, donate_time, donate_value, dog_no, member_no, shelter_no) VALUES (165, 1692238470, 10000, 91, 20, 37);
INSERT INTO mydb.donation (donation_no, donate_time, donate_value, dog_no, member_no, shelter_no) VALUES (166, 1692238474, 10000, 91, 20, 37);
INSERT INTO mydb.donation (donation_no, donate_time, donate_value, dog_no, member_no, shelter_no) VALUES (167, 1692238475, 10000, 91, 20, 37);
INSERT INTO mydb.donation (donation_no, donate_time, donate_value, dog_no, member_no, shelter_no) VALUES (168, 1692238816, 33, 54, 24, 12);
INSERT INTO mydb.donation (donation_no, donate_time, donate_value, dog_no, member_no, shelter_no) VALUES (169, 1692238834, 11, 1, 24, 12);
INSERT INTO mydb.donation (donation_no, donate_time, donate_value, dog_no, member_no, shelter_no) VALUES (171, 1692246225, 22, 1, 24, 12);
INSERT INTO mydb.donation (donation_no, donate_time, donate_value, dog_no, member_no, shelter_no) VALUES (172, 1692246228, 22, 1, 24, 12);
INSERT INTO mydb.donation (donation_no, donate_time, donate_value, dog_no, member_no, shelter_no) VALUES (173, 1692246398, 22, 1, 24, 12);
INSERT INTO mydb.donation (donation_no, donate_time, donate_value, dog_no, member_no, shelter_no) VALUES (174, 1692246491, 22, 1, 24, 12);
INSERT INTO mydb.donation (donation_no, donate_time, donate_value, dog_no, member_no, shelter_no) VALUES (175, 1692246501, 25, 1, 24, 12);
INSERT INTO mydb.donation (donation_no, donate_time, donate_value, dog_no, member_no, shelter_no) VALUES (176, 1692246601, 28, 1, 24, 12);
INSERT INTO mydb.donation (donation_no, donate_time, donate_value, dog_no, member_no, shelter_no) VALUES (177, 1692246618, 6, 1, 24, 12);
INSERT INTO mydb.donation (donation_no, donate_time, donate_value, dog_no, member_no, shelter_no) VALUES (178, 1692246624, 12, 1, 24, 12);
INSERT INTO mydb.donation (donation_no, donate_time, donate_value, dog_no, member_no, shelter_no) VALUES (179, 1692246634, 16, 1, 24, 12);
INSERT INTO mydb.donation (donation_no, donate_time, donate_value, dog_no, member_no, shelter_no) VALUES (180, 1692246638, 26, 1, 24, 12);
INSERT INTO mydb.donation (donation_no, donate_time, donate_value, dog_no, member_no, shelter_no) VALUES (181, 1692246644, 25, 1, 24, 12);
INSERT INTO mydb.donation (donation_no, donate_time, donate_value, dog_no, member_no, shelter_no) VALUES (182, 1692247004, 222, 1, 24, 12);
INSERT INTO mydb.donation (donation_no, donate_time, donate_value, dog_no, member_no, shelter_no) VALUES (183, 1692247015, 4, 1, 24, 12);
INSERT INTO mydb.donation (donation_no, donate_time, donate_value, dog_no, member_no, shelter_no) VALUES (218, 1692261939, 100000, 135, 24, 12);
INSERT INTO mydb.donation (donation_no, donate_time, donate_value, dog_no, member_no, shelter_no) VALUES (219, 1692261947, 100000, 135, 24, 12);
INSERT INTO mydb.donation (donation_no, donate_time, donate_value, dog_no, member_no, shelter_no) VALUES (220, 1692262019, 500000, 1, 32, 12);
INSERT INTO mydb.donation (donation_no, donate_time, donate_value, dog_no, member_no, shelter_no) VALUES (221, 1692269410, 300000, 1, 13, 12);
INSERT INTO mydb.donation (donation_no, donate_time, donate_value, dog_no, member_no, shelter_no) VALUES (230, 1692276674, 3000, 187, 32, 46);
INSERT INTO mydb.donation (donation_no, donate_time, donate_value, dog_no, member_no, shelter_no) VALUES (231, 1692276689, 35000, 99, 32, 38);
INSERT INTO mydb.donation (donation_no, donate_time, donate_value, dog_no, member_no, shelter_no) VALUES (232, 1692276701, 300000, 1, 32, 12);
