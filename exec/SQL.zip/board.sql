create table board
(
    board_no      int           not null
        primary key,
    content       text          not null,
    created_time  bigint        not null,
    deleted_time  bigint        null,
    image_path    varchar(255)  null,
    modified_time bigint        null,
    title         varchar(100)  not null,
    view_cnt      int default 0 not null,
    member_no     int           null,
    constraint FKbuilrr84cdwl9mlya721oe7jp
        foreign key (member_no) references member (user_no)
);

INSERT INTO mydb.board (board_no, content, created_time, deleted_time, image_path, modified_time, title, view_cnt, member_no) VALUES (23, 'ddd', 1692099848, 1692100833, null, null, 'ddd', 8, 24);
INSERT INTO mydb.board (board_no, content, created_time, deleted_time, image_path, modified_time, title, view_cnt, member_no) VALUES (50, '강아지 너무 귀여워요!!
제가 봤던 모습 그대로라 더 좋아요 ㅎㅎㅎㅎㅎㅎ', 1692146589, null, 'e0491040-909d-443c-a903-37f370f6b3bf_dog-5357794_640.jpg', 1692228905, '펫미팅 덕분에 행복한 시간 보내고 있습니다', 124, 24);
INSERT INTO mydb.board (board_no, content, created_time, deleted_time, image_path, modified_time, title, view_cnt, member_no) VALUES (111, 'ㅇㅇ', 1692201157, 1692201160, 'e05d3033-532f-49ee-861a-420ecfdf3c2c_캡처234.JPG', null, 'ㅇㅇ', 1, 24);
INSERT INTO mydb.board (board_no, content, created_time, deleted_time, image_path, modified_time, title, view_cnt, member_no) VALUES (185, '이러고 기다리고 있네요 ㅎㅎㅎ', 1692252575, null, 'dfef691a-8f43-4343-af99-8e0c9142cd0c_111500268.2.jpg', null, '오늘 늦게 집에 갔더니', 6, 24);
INSERT INTO mydb.board (board_no, content, created_time, deleted_time, image_path, modified_time, title, view_cnt, member_no) VALUES (205, '뽀삐 사진 보고 가세요!!', 1692260869, null, 'e2141fd4-df57-4d4a-9268-e024726c19cf_puppy.jpeg', null, '얌전한 뽀삐에요', 4, 44);
INSERT INTO mydb.board (board_no, content, created_time, deleted_time, image_path, modified_time, title, view_cnt, member_no) VALUES (223, '달마시안, 그 아름다운 모습으로 우리를 감동시키는 찬란한 존재입니다. 그 유려한 몸짓과 우아한 움직임은 마치 예술작품을 감상하듯 우리의 눈과 마음을 사로잡습니다. 달마시안의 품종은 그만한 미를 가진 개들 중에서도 돋보이며, 그 특유의 털빛과 눈빛은 마치 별들이 빛나는 밤하늘처럼 아름다움을 품고 있습니다.

하지만 달마시안은 그 뿐만이 아닙니다. 그들은 또한 충성스럽고 지적인 동반자로서 우리의 일상을 풍요롭게 만들어줍니다. 그들의 촉촉한 코와 따뜻한 눈빛은 우리에게 끊임없는 사랑과 이해를 줍니다. 그들과 함께하는 시간은 마치 힐링 같은 순간들로 가득차며, 서로에게 힘과 위로를 줄 수 있는 소중한 존재입니다.

달마시안은 뛰어난 지능과 민첩성을 가졌기 때문에 다양한 훈련과 활동을 통해 그들의 재능을 발휘할 수 있습니다. 그들은 운동을 사랑하며, 뛰어난 체력과 에너지를 소유하고 있어 함께 활동하는 것이 어렵지 않습니다. 또한 그들의 호기심과 지적인 능력을 이용하여 다양한 퍼즐이나 게임을 즐기며 똑똑한 머리를 빛낼 수 있습니다.

그리고 무엇보다도, 달마시안은 우리와의 무한한 사랑과 인연을 맺습니다. 그들은 우리의 가족이자 친구이며, 그들과 함께하는 모든 순간은 소중하고 특별한 추억으로 남을 것입니다. 달마시안의 아름다움과 온기는 우리의 삶을 빛나게 하며, 그들과 함께하는 시간은 언제나 행복과 감사로 가득차게 만들어줍니다.', 1692276294, null, '553b00c6-839d-4961-af93-bbaa980c6666_dalma.jpg', null, '달마시안, 그 빛나는 존재', 2, 44);
INSERT INTO mydb.board (board_no, content, created_time, deleted_time, image_path, modified_time, title, view_cnt, member_no) VALUES (224, '푸들, 그 사랑스러운 모습으로 우리의 마음을 사로잡는 사랑스러운 동반자입니다. 그 동그란 눈과 부드러운 털은 마치 누구나 포근한 품에 안아주고 싶은 따스한 존재로 느껴집니다. 푸들은 그들만의 독특한 매력으로 사랑을 받으며, 우리의 가정을 따뜻하게 밝혀주는 소중한 멤버입니다.

푸들의 품종은 다양한 크기와 컬러를 가지고 있지만, 어떤 푸들이던지 그들의 귀여운 외모와 사랑스러운 모습은 마치 작은 천사와 같습니다. 그들의 뛰어난 지능과 순발력은 다양한 훈련과 활동을 통해 더욱 빛을 발하며, 우리의 일상을 더욱 풍요롭게 만들어줍니다.', 1692276409, null, '8ea98a1c-3990-4701-9f30-d5c9b719af19_puddle.png', null, '푸들, 사랑스러운 동반자', 5, 32);
INSERT INTO mydb.board (board_no, content, created_time, deleted_time, image_path, modified_time, title, view_cnt, member_no) VALUES (228, ' 초코와 함께하는 일상은 매일 새로운 기쁨으로 가득차요. 아침에 깨어나면 그 기쁘게 흔들리는 꼬리와 사랑스러운 모습으로 인사를 해주는 초코는 마치 작은 행복의 축제 같습니다. 산책을 나가면 초코는 주변의 모든 것들을 흥미롭게 여기며, 그 눈빛 하나로도 우리에게 무한한 행복을 선사합니다. 식사 시간이 되면 초코의 귀여운 먹방 연기가 일상의 작은 즐거움이 되며, 놀이 시간에는 우리와 함께 즐겁게 뛰어놀며 에너지를 발산합니다. 밤이 되면 초코는 우리 곁에서 편안한 휴식을 취하며, 그의 존재는 우리의 마음을 평온하게 만들어줍니다. 이 모든 일상은 초코와 함께하는 특별한 순간들로 가득차며, 그의 사랑과 충성은 우리에게 늘 큰 위안과 행복을 선사해주죠. ?❤️', 1692276613, null, 'b8a6b8ad-7485-40f3-8acd-8750e51dbbf3_choco.jpg', null, '초코와 함께 즐거운 하루 보내고 있어요', 2, 32);
