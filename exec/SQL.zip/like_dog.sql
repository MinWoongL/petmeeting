create table like_dog
(
    like_dog_no int not null
        primary key,
    dog_no      int null,
    member_no   int null,
    constraint FK44cxa9r253r5b30gv66ov1t3u
        foreign key (member_no) references member (user_no),
    constraint FKhqc5jrtua4p4xv81gsbestge2
        foreign key (dog_no) references dog (dog_no)
);

INSERT INTO mydb.like_dog (like_dog_no, dog_no, member_no) VALUES (77, 57, 36);
INSERT INTO mydb.like_dog (like_dog_no, dog_no, member_no) VALUES (78, 1, 36);
INSERT INTO mydb.like_dog (like_dog_no, dog_no, member_no) VALUES (79, 56, 36);
INSERT INTO mydb.like_dog (like_dog_no, dog_no, member_no) VALUES (80, 54, 36);
INSERT INTO mydb.like_dog (like_dog_no, dog_no, member_no) VALUES (112, 1, 13);
INSERT INTO mydb.like_dog (like_dog_no, dog_no, member_no) VALUES (123, 99, 43);
INSERT INTO mydb.like_dog (like_dog_no, dog_no, member_no) VALUES (125, 96, 43);
INSERT INTO mydb.like_dog (like_dog_no, dog_no, member_no) VALUES (131, 1, 32);
INSERT INTO mydb.like_dog (like_dog_no, dog_no, member_no) VALUES (142, 54, 42);
INSERT INTO mydb.like_dog (like_dog_no, dog_no, member_no) VALUES (164, 91, 20);
INSERT INTO mydb.like_dog (like_dog_no, dog_no, member_no) VALUES (207, 54, 44);
INSERT INTO mydb.like_dog (like_dog_no, dog_no, member_no) VALUES (210, 189, 44);
INSERT INTO mydb.like_dog (like_dog_no, dog_no, member_no) VALUES (211, 198, 44);
INSERT INTO mydb.like_dog (like_dog_no, dog_no, member_no) VALUES (235, 189, 32);
