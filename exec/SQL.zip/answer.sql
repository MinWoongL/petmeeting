create table answer
(
    answer_no int  not null
        primary key,
    content   text not null
);

