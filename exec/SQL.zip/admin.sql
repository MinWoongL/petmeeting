create table admin
(
    user_no int not null
        primary key,
    constraint FKmor5ae4un3hi7ukk06xyj1qaw
        foreign key (user_no) references users (user_no)
);

